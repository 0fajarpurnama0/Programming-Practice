<html>
<head>
<title> Hello World </title>
</head>
<body>

<?php
echo "Hello World!<br>";

// This is a single-line comment

# This is also a single-line

/*
This is
a multi-line
comment
*/

//Comment in the middle

$x = 5 /* it should be 10 */ + 5;
echo $x;
?>

</body>
</html>
