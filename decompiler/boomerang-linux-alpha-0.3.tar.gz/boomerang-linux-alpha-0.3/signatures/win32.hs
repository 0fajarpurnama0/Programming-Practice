windows.h
mfc.h
ntddk.h
ntifs.h