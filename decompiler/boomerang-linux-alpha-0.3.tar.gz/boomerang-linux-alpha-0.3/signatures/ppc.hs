stat_ppc.h
