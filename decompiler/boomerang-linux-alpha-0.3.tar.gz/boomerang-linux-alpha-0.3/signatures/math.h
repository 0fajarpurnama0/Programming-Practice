double tan(double angle);
double sqrt(double arg);
double sin(double arg);
double pow(double x, double y);
float powf(float x, float y);
