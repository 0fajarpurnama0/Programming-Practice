package rest.sample;
import java.util.*;
import javax.servlet.http.HttpServletRequest;
import dao.*;

/**
 *  Simple REST with JSONP sample using JSONIC GET & POST with MySQL, version 2014-06-17
 *  Copyright 2014 Hiroshi Nakano nakano@cc.kumamoto-u.ac.jp
 */
public class DbSampleService {
	DaoSimple dao = new DaoSimple(); // initialize dao at initializing the class / dao をクラス生成時に初期化
	public HttpServletRequest request; // for getting remote ip / アクセス元のIPアドレス取得のため

	/**
	 * Default method for GET (find) / GETのデフォルトメソッド (find)
	 * @return : JSONP string
	 */
	public ArrayList<LinkedHashMap<String,Object>> find(LinkedHashMap<String,Object> parms) {
		ArrayList<LinkedHashMap<String,Object>> ret = new ArrayList<LinkedHashMap<String,Object>>();
		if(parms.get("name") != null) {
			LinkedHashMap<String,Object> line = new LinkedHashMap<String,Object>();
//			for(String key : parms.keySet())	System.out.println(key+":"+parms.get(key));
//			byte[] b = ((String)(parms.get("name"))).getBytes();
//			for(int i = 0; i < b.length; i++) System.out.print(String.format("%x ", b[i]));
			line.put("name", convertToOiginal((String)parms.get("name")));
			line.put("text", convertToOiginal((String)parms.get("text")));
			line.put("ip", request.getRemoteAddr());
			line.put("last", String.format("%1$tF %1$tT", Calendar.getInstance()));
			for(String key : line.keySet())	System.out.println(key+":"+line.get(key));
			ret.add(dao.addLine(line));
		} else {
			ret = dao.getAll();
		}
		return ret;
	}
	
	/**
	 * Default method for POST (create) / POSTのデフォルトメソッド (create)
	 * @param parms : hash array / 連想配列(項目名と値)
	 * @return : LinkedHashMap<String,Object> (number of lines added successfully / 追加した行数)
	 */
	public LinkedHashMap<String,Object> create(LinkedHashMap<String,Object> parms) {
		LinkedHashMap<String,Object> line = new LinkedHashMap<String,Object>();
		line.put("name", parms.get("name"));
		line.put("text", parms.get("text"));
		line.put("ip", request.getRemoteAddr());
		line.put("last", String.format("%1$tF %1$tT", Calendar.getInstance()));
		for(String key : line.keySet())	System.out.println(key+":"+line.get(key));
		return dao.addLine(line);
	}

	/**
	 * convert from web encoded text including unicode to utf8
	 * Unicodeを含むWebエンコードされた文字列から元の文字列に変換する ("%u3042" -> "あ", "%20" -> " ")
	 * 参考サイト: http://qiita.com/sifue/items/039846cf8415efdc5c92
	 * @param unicode
	 * @return
	 */
	private static String convertToOiginal(String unicode)
	{
	    String[] codeStrs = unicode.split("%");
	    String encodedText = codeStrs[0]; // if not unicode
//	    for(String s: codeStrs) System.out.println(s);
  		int[] codePoints = new int[1];
	    for(int i = 1; i < codeStrs.length; i++) {
	    	if(codeStrs[i].startsWith("u")) {
	    		codePoints[0] = Integer.parseInt(codeStrs[i].substring(1, 5), 16);
	    		encodedText += new String(codePoints, 0, codePoints.length);
	    		if(codeStrs[i].length() > 5) {
	    			encodedText += codeStrs[i].substring(5,codeStrs[i].length());
	    		}
	    	} else {
	    		codePoints[0] = Integer.parseInt(codeStrs[i].substring(0, 2), 16);
	    		encodedText += new String(codePoints, 0, codePoints.length);
	    		if(codeStrs[i].length() > 2) {
	    			encodedText += codeStrs[i].substring(2,codeStrs[i].length());
	    		}
	    	}
	    }
	    return encodedText;
	}

}