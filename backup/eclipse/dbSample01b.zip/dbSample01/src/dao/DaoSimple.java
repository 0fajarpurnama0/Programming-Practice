package dao;
import java.util.*;
import java.sql.*;

/**
 * Very simple sample class for data access object
 * @author nakano@cc.kumamoto-u.ac.jp
 * @version 20140617
 */
public class DaoSimple {
	// these three parameters are set at the external file sys.properties / これらの3変数は、外部ファイル sys.properties で決まる
	private String dbDriver = null;
	private String dbUri = null;
	private Properties dbProps = null;

	/**
	 * Constructor
	 * read parameters for db access from external file
	 */
	public DaoSimple() {
		try {
			ResourceBundle bundle = ResourceBundle.getBundle("sys"); // set config file as "src/sys.property" / 設定ファイルは"src/sys.property"
			// get following parameters from above file / 上記ファイルから以下のパラメータを読み込む
			dbDriver = bundle.getString("driver");
			dbUri = bundle.getString("uri");
			dbProps = new Properties();
			dbProps.put("user", bundle.getString("user"));
			dbProps.put("password", bundle.getString("password"));
			dbProps.put("characterEncoding", "UTF8"); // need for multibyte chars. / 日本語等ではこれが必要
		} catch (MissingResourceException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * getAll() method
	 * get all data from "comment" table
	 */
	public ArrayList<LinkedHashMap<String,Object>> getAll() {
		ArrayList<LinkedHashMap<String,Object>> ret = new ArrayList<LinkedHashMap<String,Object>>();
		String queryStr = "select * from comment order by last desc";
		Connection conn = null; // these three variables for db connection / ここからの3変数はDB接続に使用
		Statement state = null;
		ResultSet rs = null;
		try {
			Class.forName(dbDriver).newInstance(); // Instantiation of mySQL jdbc driver. / mySQLのjdbcドライバのインスタンス化
			System.out.println("Class.forName(dbDriver).newInstance().toString()="+Class.forName(dbDriver).newInstance().toString());
			conn = DriverManager.getConnection(dbUri, dbProps);
			conn.setAutoCommit(true);
			state = conn.createStatement();
			rs = state.executeQuery(queryStr); // executing query / queryの実行
			ArrayList<String> key = new ArrayList<String>();
			// obtain column name / カラム名の取得
			for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
				key.add(rs.getMetaData().getColumnName(i)); // add column names to keys / カラム名のリストをキーに追加
			}
			// obtain query results / queryの結果を得る
			LinkedHashMap<String,Object> line; // for restoring 1 line (row) data / 1行分のデータ記憶用
			while (rs.next()) {
				line = new LinkedHashMap<String,Object>();
				for (int i = 1; i <= rs.getMetaData().getColumnCount(); i++) {
					line.put(key.get(i-1), rs.getObject(i));
				}
				ret.add(line);
			}
			//for exception
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				rs.close();
				state.close();
				conn.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		System.out.println("ret=" + ret.toString());
		return ret;
	}
	
	/**
	 * addLine() method
	 * add a line to "comment" table
	 */
	public LinkedHashMap<String,Object> addLine(LinkedHashMap<String,Object> line) {
		LinkedHashMap<String,Object> ret = new LinkedHashMap<String,Object>();
		Connection conn = null; // these two variables for db connection / ここからの2変数はDB接続に使用
		Statement state = null;
		try {
			Class.forName(dbDriver).newInstance(); // Instantiation of mySQL jdbc driver. / mySQLのjdbcドライバのインスタンス化
			conn = DriverManager.getConnection(dbUri, dbProps);
			conn.setAutoCommit(true);
			state = conn.createStatement();
			PreparedStatement pStr = null;
			String sStr = null;
			sStr = "insert into comment (name, text, ip, last) values (?, ?, ?, ?)";
			pStr = conn.prepareStatement(sStr);
			pStr.setString(1, line.get("name").toString());
			pStr.setString(2, line.get("text").toString());
			pStr.setString(3, line.get("ip").toString());
			pStr.setTimestamp(4, java.sql.Timestamp.valueOf(line.get("last").toString()));
			pStr.execute();
			ret.put("number of added lines", pStr.getUpdateCount());
			//for exception
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			try {
				state.close();
				conn.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
		return ret;
	}

	/**
	 * main method for check
	 * @param args
	 */
	public static void main(String[] args) {
		DaoSimple dao = new DaoSimple();
		LinkedHashMap<String,Object> line = new LinkedHashMap<String,Object>();
		line.put("name", "名前"); line.put("text", "文章よ"); line.put("ip", "133.95.45.1"); line.put("last", "2014-02-03 18:42:00");
		System.out.println("add = " + dao.addLine(line));
		ArrayList<LinkedHashMap<String,Object>>  all = dao.getAll();
		for(LinkedHashMap<String,Object> l : all) {
			for(String key : l.keySet()) {
				System.out.print(key+":"+l.get(key)+", ");
			}
			System.out.println("");
		}
	}
	
}